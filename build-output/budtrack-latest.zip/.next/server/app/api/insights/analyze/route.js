"use strict";(()=>{var e={};e.id=7869,e.ids=[7869],e.modules={53524:e=>{e.exports=require("@prisma/client")},67096:e=>{e.exports=require("bcrypt")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},39491:e=>{e.exports=require("assert")},14300:e=>{e.exports=require("buffer")},6113:e=>{e.exports=require("crypto")},82361:e=>{e.exports=require("events")},13685:e=>{e.exports=require("http")},95687:e=>{e.exports=require("https")},63477:e=>{e.exports=require("querystring")},57310:e=>{e.exports=require("url")},73837:e=>{e.exports=require("util")},59796:e=>{e.exports=require("zlib")},70815:(e,a,n)=>{n.r(a),n.d(a,{originalPathname:()=>k,patchFetch:()=>f,requestAsyncStorage:()=>g,routeModule:()=>d,serverHooks:()=>y,staticGenerationAsyncStorage:()=>m});var t={};n.r(t),n.d(t,{POST:()=>c});var r=n(49303),i=n(88716),s=n(60670),o=n(87070),u=n(75571),l=n(90455),p=n(72331);async function c(e){try{let a=await (0,u.getServerSession)(l.L);if(!a?.user?.id)return o.NextResponse.json({error:"Unauthorized"},{status:401});let{walletId:n,startDate:t,endDate:r}=await e.json();if(!n)return o.NextResponse.json({error:"Wallet ID is required"},{status:400});let i=await p.Z.transaction.findMany({where:{walletId:n,userId:a.user.id,date:{gte:t?new Date(t):void 0,lte:r?new Date(r):void 0}},include:{category:!0}}),s=i.filter(e=>"INCOME"===e.type).reduce((e,a)=>e+a.amount,0),c=i.filter(e=>"EXPENSE"===e.type).reduce((e,a)=>e+a.amount,0),d=s-c,g={};i.forEach(e=>{let a=e.date.toISOString().slice(0,7);g[a]||(g[a]={income:0,expense:0}),"INCOME"===e.type?g[a].income+=e.amount:g[a].expense+=e.amount});let m={};Object.keys(g).sort().forEach(e=>{m[e]=g[e]});let y=i.filter(e=>"EXPENSE"===e.type&&e.category).reduce((e,a)=>{let n=a.category?.name||"Uncategorized";return e[n]=(e[n]||0)+a.amount,e},{}),k=i.filter(e=>"INCOME"===e.type&&e.category).reduce((e,a)=>{let n=a.category?.name||"Uncategorized";return e[n]=(e[n]||0)+a.amount,e},{});await p.Z.userSettings.findUnique({where:{userId:a.user.id}});let f=Object.keys(m),h=f[f.length-1],b=f[f.length-2],x={incomeChange:0,expenseChange:0};if(h&&b){let e=m[h],a=m[b];x={incomeChange:(e.income-a.income)/a.income*100,expenseChange:(e.expense-a.expense)/a.expense*100}}let A=Object.entries(y).map(([e,a])=>({category:e,amount:a,percentage:a/c*100})).sort((e,a)=>a.amount-e.amount).slice(0,3),j=function(e){let a=e=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",minimumFractionDigits:0}).format(e);return`Sebagai seorang financial advisor profesional, buatkan ringkasan keuangan singkat dan informatif berdasarkan data berikut:

# Ringkasan Keuangan Bulan Ini

## Data Keuangan
- Total Pemasukan: ${a(e.totalIncome)}
- Total Pengeluaran: ${a(e.totalExpense)}
- Total Tabungan: ${a(e.netSavings)}

## Top 3 Pengeluaran Terbesar
${e.topExpenses.map(e=>`- ${e.category}: ${a(e.amount)} (${e.percentage.toFixed(1)}%)`).join("\n")}

## Perubahan dari Bulan Sebelumnya
- Pemasukan: ${e.monthlyTrend.incomeChange.toFixed(1)}%
- Pengeluaran: ${e.monthlyTrend.expenseChange.toFixed(1)}%

Berikan ringkasan dalam format berikut:

1. **Kondisi Keuangan**: Overview kondisi keuangan secara umum
2. **Highlight**: Pengeluaran yang perlu perhatian khusus
3. **Rekomendasi**: Saran berdasarkan tren

*Gunakan bahasa Jaksel Gaul, tapi jangan ada kata jaksel/kata kata yg norak. Fokus pada insight yang paling relevan.*`}({totalIncome:s,totalExpense:c,netSavings:d,topExpenses:A,monthlyTrend:x}),P=function(e){let a=e=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",minimumFractionDigits:0}).format(e),n=Object.keys(e.monthlyData),t=n.reduce((a,n)=>a+e.monthlyData[n].income,0)/n.length,r=n.reduce((a,n)=>a+e.monthlyData[n].expense,0)/n.length,i=Object.entries(e.categories).map(([a,n])=>({category:a,percentage:(n/e.yearlyTotals.expense*100).toFixed(1)})).sort((e,a)=>parseFloat(a.percentage)-parseFloat(e.percentage));return`Sebagai seorang financial analyst profesional, lakukan analisis mendalam terhadap data keuangan berikut:

# ANALISIS KEUANGAN MENDALAM

## RINGKASAN TAHUNAN
- Total Pemasukan: ${a(e.yearlyTotals.income)}
- Total Pengeluaran: ${a(e.yearlyTotals.expense)}
- Total Tabungan: ${a(e.yearlyTotals.savings)}

## RATA-RATA BULANAN
- Pemasukan: ${a(t)}
- Pengeluaran: ${a(r)}

## DISTRIBUSI PENGELUARAN
${i.map(e=>`- ${e.category}: ${e.percentage}%`).join("\n")}

### 1. ANALISIS POLA PENGELUARAN
- Identifikasi kategori pengeluaran yang perlu perhatian khusus
- Analisis apakah distribusi pengeluaran sudah ideal
- Rekomendasi untuk optimasi pengeluaran

### 2. ANALISIS TABUNGAN & KESEHATAN FINANSIAL
- Evaluasi rasio tabungan terhadap pemasukan
- Rekomendasi target tabungan yang ideal
- Saran untuk meningkatkan kesehatan finansial

### 3. REKOMENDASI STRATEGIS
- 2-3 langkah konkret untuk perbaikan keuangan
- Identifikasi potensi penghematan
- Saran alokasi dana yang lebih efektif

*Berikan analisis dalam format yang terstruktur dengan poin-poin yang jelas. Gunakan bahasa Jaksel Gaul, tapi jangan ada kata jaksel/kata kata yg norak.*`}({transactions:i,monthlyData:m,categories:y,yearlyTotals:{income:s,expense:c,savings:d}});return o.NextResponse.json({data:{totalIncome:s,totalExpense:c,netSavings:d,expensesByCategory:y,incomeByCategory:k,monthlyData:m},analysis:j,summaryPrompt:j,smartAnalysisPrompt:P})}catch(e){return console.error("Error analyzing transactions:",e),o.NextResponse.json({error:"Failed to analyze transactions"},{status:500})}}let d=new r.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/insights/analyze/route",pathname:"/api/insights/analyze",filename:"route",bundlePath:"app/api/insights/analyze/route"},resolvedPagePath:"D:\\DATA\\Documents\\code\\Tes\\budtrack\\app\\api\\insights\\analyze\\route.ts",nextConfigOutput:"",userland:t}),{requestAsyncStorage:g,staticGenerationAsyncStorage:m,serverHooks:y}=d,k="/api/insights/analyze/route";function f(){return(0,s.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:m})}},19579:(e,a,n)=>{n.d(a,{L:()=>u});var t=n(7585),r=n(53524),i=n(67096),s=n(53797);let o=new r.PrismaClient,u={adapter:(0,t.N)(o),providers:[(0,s.Z)({name:"credentials",credentials:{email:{label:"Email",type:"email"},password:{label:"Password",type:"password"}},async authorize(e){if(!e?.email||!e?.password)return null;let a=await o.user.findUnique({where:{email:e.email}});return a&&a.password&&await (0,i.compare)(e.password,a.password)?{id:a.id,email:a.email,name:a.name,image:a.image}:null}})],session:{strategy:"jwt"},callbacks:{jwt:async({token:e,user:a,account:n})=>a?{...e,id:a.id}:e,session:async({session:e,token:a})=>({...e,user:{...e.user,id:a.id}})},pages:{signIn:"/auth/signin"},debug:!1,secret:process.env.NEXTAUTH_SECRET}},90455:(e,a,n)=>{n.d(a,{L:()=>t.L});var t=n(19579)},72331:(e,a,n)=>{n.d(a,{Z:()=>r});var t=n(53524);let r=globalThis.prisma??new t.PrismaClient({log:["query","error","warn"]})},69955:(e,a)=>{Object.defineProperty(a,"__esModule",{value:!0})},75571:(e,a,n)=>{Object.defineProperty(a,"__esModule",{value:!0});var t={};Object.defineProperty(a,"default",{enumerable:!0,get:function(){return i.default}});var r=n(69955);Object.keys(r).forEach(function(e){!("default"===e||"__esModule"===e||Object.prototype.hasOwnProperty.call(t,e))&&(e in a&&a[e]===r[e]||Object.defineProperty(a,e,{enumerable:!0,get:function(){return r[e]}}))});var i=function(e,a){if(e&&e.__esModule)return e;if(null===e||"object"!=typeof e&&"function"!=typeof e)return{default:e};var n=s(void 0);if(n&&n.has(e))return n.get(e);var t={__proto__:null},r=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var i in e)if("default"!==i&&({}).hasOwnProperty.call(e,i)){var o=r?Object.getOwnPropertyDescriptor(e,i):null;o&&(o.get||o.set)?Object.defineProperty(t,i,o):t[i]=e[i]}return t.default=e,n&&n.set(e,t),t}(n(45609));function s(e){if("function"!=typeof WeakMap)return null;var a=new WeakMap,n=new WeakMap;return(s=function(e){return e?n:a})(e)}Object.keys(i).forEach(function(e){!("default"===e||"__esModule"===e||Object.prototype.hasOwnProperty.call(t,e))&&(e in a&&a[e]===i[e]||Object.defineProperty(a,e,{enumerable:!0,get:function(){return i[e]}}))})}};var a=require("../../../../webpack-runtime.js");a.C(e);var n=e=>a(a.s=e),t=a.X(0,[1633,5544,5972],()=>n(70815));module.exports=t})();
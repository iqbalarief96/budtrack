# BudTrack - Aplikasi Manajemen Keuangan

Aplikasi manajemen keuangan berbasis web untuk melacak pengeluaran, pendapatan, dan anggaran.

## Fitur Utama

- Dashboard keuangan
- Manajemen transaksi (pemasukan & pengeluaran)
- Pengelolaan dompet/rekening
- Pengelolaan kategori
- Anggaran belanja
- Transaksi berulang
- Analisis keuangan
- Laporan dan ekspor data
- Smart kategorisasi

## Cara Menjalankan Aplikasi

```bash
# Install dependensi
npm install

# Jalankan development server
npm run dev
```

## Database Management

### Backup Database

Untuk membuat backup database, jalankan script PowerShell yang disediakan:

```powershell
.\backup.ps1
```

Script akan:
1. Membuat backup dari database SQLite dengan timestamp
2. Menyimpan backup di folder `backups/`
3. Mengelola jumlah backup (maksimal 10, bisa diubah di script)
4. Menampilkan daftar backup yang tersedia

### Restore Database

Untuk mengembalikan database dari backup:

1. Matikan server aplikasi (Ctrl+C di terminal)
2. Salin file backup ke lokasi database asli:
   ```powershell
   Copy-Item "backups/[NAMA_FILE_BACKUP]" "prisma/dev.db" -Force
   ```
3. Jalankan kembali server aplikasi:
   ```powershell
   npm run dev
   ```

### Seed Database

Aplikasi menyediakan beberapa script untuk mengisi database dengan data contoh:

```powershell
# Menambahkan kategori
npx ts-node prisma/seed.ts

# Menambahkan dompet
npx ts-node prisma/walletSeed.ts

# Menambahkan transaksi
npx ts-node prisma/transactionSeed.ts

# Menambahkan anggaran
npx ts-node prisma/budgetSeed.ts
``` 